# 🗺️ Índice del Proyecto: Arquitectura QuickStay Mejorada

[![Network](https://img.shields.io/badge/Network-Operational-green)](#)
[![Active Directory](https://img.shields.io/badge/AD-In_Progress-yellow)](#)
[![Web Cluster](https://img.shields.io/badge/Web_HA-Pending-lightgrey)](#)
**Descripción:** Plan de realización detallado para la implementación de infraestructura de Alta Disponibilidad, IoT y Seguridad.
**Duración Total:** 14 Semanas (70 días hábiles)
**Estado:** 🟢 En Progreso

---

## 📑 Tabla de Contenidos

### Fase 1: Planificación y Diseño Detallado

#### 📂 [Semana 1: Diseño de Arquitectura](./semana_01.md)
- [ ] **Día 1-2:** [Requisitos y SLA](./semana_01.md#día-1-2-revisión-y-documentación-de-requisitos-ampliados)
- [ ] **Día 3-4:** [Diseño de Red Mejorado](./semana_01.md#día-3-4-diseño-de-red-mejorado)
- [ ] **Día 5:** [Diseño de Seguridad](./semana_01.md#día-5-diseño-de-seguridad)

#### 📂 [Semana 2: Especificaciones y Plan de Pruebas](./semana_02.md)
- [ ] **Día 6-7:** [Especificación de Componentes](./semana_02.md#día-6-7-especificación-de-componentes)
- [ ] **Día 8-9:** [Plan de Pruebas Detallado](./semana_02.md#día-8-9-plan-de-pruebas-detallado)
- [ ] **Día 10:** [Cronograma y Recursos](./semana_02.md#día-10-cronograma-y-asignación-de-recursos)

---

### Fase 2: Implementación de Infraestructura de Red

#### 📂 [Semana 3: Red Base y Seguridad](./semana_03.md)
- [ ] **Día 11-12:** [Configuración Router/Firewall](./semana_03.md#día-11-12-configuración-de-routerfirewall-packet-tracer)
- [ ] **Día 13-14:** [Switch L3 y VLANs](./semana_03.md#día-13-14-switch-l3-y-vlans)
- [ ] **Día 15:** [Conectividad y Pruebas](./semana_03.md#día-15-conectividad-básica-y-pruebas)

#### 📂 [Semana 4: Servicios de Infraestructura HA](./semana_04.md)
- [ ] **Día 16-17:** [Active Directory Redundante](./semana_04.md#día-16-17-active-directory-con-redundancia)
- [ ] **Día 18-19:** [DNS Redundante](./semana_04.md#día-18-19-servicios-dns-redundantes)
- [ ] **Día 20:** [DHCP y Servicios Base](./semana_04.md#día-20-dhcp-y-otros-servicios-base)

---

### Fase 3: Implementación de Servicios Críticos

#### 📂 [Semana 5: Capa Web con Alta Disponibilidad](./semana_05.md)
- [ ] **Día 21-22:** [Balanceador F5](./semana_05.md#día-21-22-balanceador-de-carga-f5-simulado)
- [ ] **Día 23-24:** [Web Servers Redundantes](./semana_05.md#día-23-24-servidores-web-redundantes)
- [ ] **Día 25:** [Pruebas Capa Web](./semana_05.md#día-25-pruebas-de-capa-web)

#### 📂 [Semana 6: Capa de Aplicación y BD](./semana_06.md)
- [ ] **Día 26-27:** [App Servers Java](./semana_06.md#día-26-27-servidores-de-aplicación-java)
- [ ] **Día 28-29:** [MySQL HA](./semana_06.md#día-28-29-base-de-datos-mysql-ha)
- [ ] **Día 30-31:** [Integración 3-Capas](./semana_06.md#día-30-31-integración-completa-3-capas)

#### 📂 [Semana 7: IoT y Gestión](./semana_07.md)
- [ ] **Día 32-33:** [Infraestructura IoT](./semana_07.md#día-32-33-infraestructura-iot-redundante)
- [ ] **Día 34-35:** [Monitoreo (Zabbix)](./semana_07.md#día-34-35-sistema-de-monitoreo-zabbix)
- [ ] **Día 36-37:** [Seguridad (Wazuh)](./semana_07.md#día-36-37-sistema-de-seguridad-wazuh)

---

### Fase 4: Sistemas de Backup y Alta Disponibilidad

#### 📂 [Semana 8: Sistema de Backup/DR](./semana_08.md)
- [ ] **Día 38-39:** [Servidor Veeam](./semana_08.md#día-38-39-servidor-de-backup-veeam-simulado)
- [ ] **Día 40-41:** [Agentes de Backup](./semana_08.md#día-40-41-configuración-de-agentes-de-backup)
- [ ] **Día 42-43:** [Pruebas de Recuperación](./semana_08.md#día-42-43-pruebas-de-recuperación)

#### 📂 [Semana 9: Optimización y Pruebas HA](./semana_09.md)
- [ ] **Día 44-45:** [Pruebas de Failover](./semana_09.md#día-44-45-pruebas-de-failover-exhaustivas)
- [ ] **Día 46-47:** [Pruebas de Rendimiento](./semana_09.md#día-46-47-pruebas-de-rendimiento)
- [ ] **Día 48:** [Ajustes y Optimizaciones](./semana_09.md#día-48-ajustes-y-optimizaciones)

---

### Fase 5: Pruebas Integrales y Documentación

#### 📂 [Semana 10: Pruebas de Integración](./semana_10.md)
- [ ] **Día 49-50:** [Pruebas Funcionales](./semana_10.md#día-49-50-pruebas-funcionales-completas)
- [ ] **Día 51-52:** [Pruebas de Seguridad](./semana_10.md#día-51-52-pruebas-de-seguridad)
- [ ] **Día 53:** [Recuperación Desastres](./semana_10.md#día-53-pruebas-de-recuperación-ante-desastres)

#### 📂 [Semana 11-12: Documentación Técnica](./semana_11_12.md)
- [ ] **Día 54-57:** [Documentación Configuración](./semana_11_12.md#día-54-57-documentación-de-configuración)
- [ ] **Día 58-60:** [Documentación Operativa](./semana_11_12.md#día-58-60-documentación-operativa)
- [ ] **Día 61-62:** [Memoria del Proyecto](./semana_11_12.md#día-61-62-memoria-del-proyecto)

#### 📂 [Semana 13: Presentación](./semana_13.md)
- [ ] **Día 63-64:** [Materiales Presentación](./semana_13.md#día-63-64-creación-de-materiales-de-presentación)
- [ ] **Día 65:** [Ensayo](./semana_13.md#día-65-ensayo-de-presentación)

#### 📂 [Semana 14: Entrega Final](./semana_14.md)
- [ ] **Día 66-67:** [Buffer Imprevistos](./semana_14.md#día-66-67-buffer-para-imprevistos)
- [ ] **Día 69-70:** [Entrega y Defensa](./semana_14.md#día-69-70-entrega-y-presentación)

---

## 📊 Hitos Críticos (Checkpoints)

| Semana | Hito | Entregable Clave | Estado |
| :--- | :--- | :--- | :---: |
| **Semana 2** | Diseño completo aprobado | 📄 Documento de diseño | ⚪ |
| **Semana 4** | Red básica funcionando | 🔌 Configs de red | ⚪ |
| **Semana 5** | AD/DNS redundante operativo | 🛡️ Pruebas failover AD | ⚪ |
| **Semana 7** | Arquitectura 3-capas completa | 🚀 Demo aplicación | ⚪ |
| **Semana 9** | Sistema HA validado | 📉 Reporte failover | ⚪ |
| **Semana 10** | Backup/DR operativo | 💾 Pruebas restauración | ⚪ |
| **Semana 12** | Documentación completa | 📚 Memoria final | ⚪ |
| **Semana 14** | Proyecto terminado | 🎤 Defensa | ⚪ |
